﻿Module globals
    Public response As Boolean = False
    Public Emotion As Integer
    Public Anger As Integer
End Module
